
let randomNumber = Math.floor(Math.random() * 100);
console.log(randomNumber)

function checkGuess() {
  const userGuess = document.getElementById('tentativa').value;
  

  if (userGuess === '') {
    document.getElementById('resultado').textContent = "Digite um número!";
    return;
  }

  const guess = parseInt(userGuess);

  if (guess === randomNumber) {
    document.getElementById('resultado').textContent = "Você acertou!";
    document.getElementById('resultado').style.backgroundColor = "green";
  } else {
    document.getElementById('resultado').textContent = "Você errou! Tente novamente.";
    document.getElementById('resultado').style.backgroundColor = "red";
  }
}

