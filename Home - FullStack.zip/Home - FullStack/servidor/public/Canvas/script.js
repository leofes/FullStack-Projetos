document.getElementById("canvas");
let ctx = canvas.getContext("2d")

function quadrado(cor_linha, cor_dentro, x, y, largura, altura) {
ctx.beginPath();
ctx.lineWidth = 2;
ctx.strokeStyle = cor_linha;
ctx.fillStyle = cor_dentro;
ctx.fillRect(x,y, largura, altura);
ctx.closePath();

}

quadrado("blue", "blue", 0,0,80,80);
quadrado("red", "red", 320,0,80,80)
quadrado("skyblue", "cyan", 0,160,40,80);
quadrado("skyblue", "cyan", 350,175,50,50)
quadrado("yellow", "yellow", 0,360,80,40)
quadrado("yellow", "yellow", 0,320,40,50)
quadrado("yellow","yellow", 360,320,40,40)
quadrado("yellow","yellow", 320, 360, 80, 40)
quadrado("red", "red", 145,200,55,55)

function circulo(cor_linha, cor_dentro, x, y, raio) {
    ctx.beginPath();
    ctx.lineWidth = 3;
    ctx.strokeStyle = cor_linha;
    ctx.fillStyle = cor_dentro;
    ctx.arc(x, y, raio, 0, Math.PI * 2, false);
    ctx.fill();
    ctx.stroke();
    ctx.closePath();
}

circulo("blue", "cyan", 200, 155, 20);  
circulo("green", "yellow", 100 , 290, 20); 
circulo("green", "yellow", 290, 290, 20);
circulo("green", "cyan", 200, 400, 55)


function arcos (linha, cor_fora, Xi, Yi, tam, RaioI, RaioF) {
    ctx.beginPath();
    ctx.lineWidth = linha;
    ctx.strokeStyle = cor_fora;
    ctx.arc(Xi,Yi,tam,RaioI,RaioF);
    ctx.stroke();
    ctx.closePath;
}

arcos(3, "green", 200, 200, 80, Math.PI, 2*Math.PI);
arcos(3, "green", 200, 200, 100, Math.PI, Math.PI/0.80);
arcos(3, "green", 200, 200, 100, 1.75*Math.PI, 0);
arcos(3, "green", 200, 400, 100, Math.PI, 1.5*Math.PI);
arcos(3, "green", 200, 400, 75, 1.5*Math.PI, 0);



function linha(cor, x1, y1, x2, y2) {
    ctx.beginPath();
    ctx.lineWidth = 2;
    ctx.strokeStyle = cor;
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.closePath();
}

linha("green", 0, 200, 400, 200);
linha("green", 200, 200, 200, 400); 
linha("blue", 0, 0, 200, 200);    
linha("red", 400, 0, 170, 230);    



ctx.beginPath();
ctx.strokeStyle = 'black';
ctx.fillStyle = 'black';
ctx.font = "25px Arial"
ctx.strokeText("Canvas",155,60);
ctx.fillText("Canvas",155,60);
ctx.closePath();

