let canvas = document.getElementById("canvas");
let ctx = canvas.getContext("2d");

let background = new Image();
background.src = "./imagens/Palmeiras.png"; 

let object = {
    x: 10,
    y: 10,
    raio: 100,
    img: new Image(),
    desenha: function() {
        ctx.beginPath();
        ctx.drawImage(this.img, this.x, this.y, 2*this.raio, 2*this.raio);
        ctx.closePath();
    }
};

background.onload = function() {

    object.img.src = "./imagens/Palmeiras.png";
    
  
    object.img.onload = function() {
        document.addEventListener("mousemove", function(evento){
            let rect = canvas.getBoundingClientRect();
            let x_mouse = evento.clientX - rect.left;
            let y_mouse = evento.clientY - rect.top;

  
            object.x = Math.min(Math.max(x_mouse - object.raio, 0), canvas.width - 2 * object.raio);
            object.y = Math.min(Math.max(y_mouse - object.raio, 0), canvas.height - 2 * object.raio);

            ctx.clearRect(0, 0, canvas.width, canvas.height); 
            ctx.drawImage(background, 0, 0, canvas.width, canvas.height);
            object.desenha(); 
        });
    };
};




